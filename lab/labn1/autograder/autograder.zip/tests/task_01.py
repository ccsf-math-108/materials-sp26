OK_FORMAT = True

test = {   'name': 'task_01',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(puromycin, pd.DataFrame)\nTrue',
                                       'failure_message': '"❌ puromycin is not a DataFrame"',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ puromycin is a DataFrame"\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
