OK_FORMAT = True

test = {   'name': 'task_10',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(gallstone, pd.DataFrame)\nTrue',
                                       'failure_message': '"❌ gallstone is not a DataFrame"',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ gallstone is a DataFrame"\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
